Tally Desk Auto — Concept by Avinash G
======================================
Double-click "Tally Desk Auto.bat":
  1. starts TallyPrime if it is not running (C:\Program Files\TallyPrime\tally.exe),
  2. opens Tally Desk (put Tally_Desk.html next to this folder or inside it),
  3. runs the bridge on 127.0.0.1:9190 and keeps it running (restarts itself if it stops).
Tally Desk finds the bridge by itself within a few seconds and switches to Live — no button to press.

Nothing is installed and nothing is downloaded: it uses Windows PowerShell.
Only this PC can use the bridge; web pages from the internet are refused.

TallyPrime setting (once per PC)
  F1 Help > Settings > Connectivity > Client/Server configuration: TallyPrime acts as Both (or Server), Port 9000.
  Open the client's company.

Extras
  "Tally Desk Auto.bat" doctor      checks TallyPrime, port 9000 and the bridge
  "Tally Desk Auto.bat" install     start the bridge automatically (minimised) at every Windows login
  "Tally Desk Auto.bat" uninstall   stop doing that
