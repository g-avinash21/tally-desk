#!/usr/bin/env python3
"""
Tally Desk — local MCP server for Claude + TallyPrime bridge + human approval gate.
Concept by Avinash G.

One file, three jobs:
  1. MCP server (stdio) so Claude Desktop can read your TallyPrime books and STAGE vouchers.
  2. HTTP bridge on 127.0.0.1:9190 used by Tally_Desk.html (/api/tally, /api/drafts, /api/ping).
  3. Approval page (/approve) — nothing Claude prepares reaches Tally until YOU click Approve.

Everything stays on this computer: Claude <-> this script <-> TallyPrime (localhost:9000).
No cloud relay of your books.

Run:
  python tally_mcp_server.py           # MCP over stdio (Claude Desktop starts this) + bridge thread
  python tally_mcp_server.py bridge    # bridge + approval page only (for Tally_Desk.html)
  python tally_mcp_server.py selftest  # checks Python setup and Tally connectivity

Env vars: TALLY_URL (default http://127.0.0.1:9000), TALLY_DESK_BRIDGE_PORT (default 9190),
          TALLY_DESK_HOME (default ~/.tallydesk)  — drafts, secret key and audit log live here.
Requires: Python 3.10+, `pip install mcp` (only for MCP mode; bridge mode uses the standard library).
"""
from __future__ import annotations

import hashlib
import hmac
import html
import json
import os
import re
import secrets
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from xml.etree import ElementTree as ET

TALLY_URL = os.environ.get("TALLY_URL", "http://127.0.0.1:9000").rstrip("/")
BRIDGE_PORT = int(os.environ.get("TALLY_DESK_BRIDGE_PORT", "9190"))
HOME = Path(os.environ.get("TALLY_DESK_HOME", str(Path.home() / ".tallydesk")))
HOME.mkdir(parents=True, exist_ok=True)
DRAFTS_FILE = HOME / "drafts.json"
SECRET_FILE = HOME / "secret.key"
AUDIT_FILE = HOME / "audit.log"
VOUCHER_TYPES = {"Sales", "Purchase", "Payment", "Receipt", "Contra", "Journal", "Credit Note", "Debit Note"}
_lock = threading.Lock()


def log(msg: str) -> None:
    """Log to stderr (stdout is reserved for the MCP protocol) and to the audit file."""
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {msg}"
    print(line, file=sys.stderr, flush=True)
    with open(AUDIT_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


# ----------------------------------------------------------------------------- Tally I/O
def esc(s) -> str:
    return (str(s if s is not None else "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;").replace("'", "&apos;"))


def tally_post(xml: str, timeout: int = 90, port: int | None = None) -> str:
    url = re.sub(r":\d+$", f":{port}", TALLY_URL) if port else TALLY_URL
    req = urllib.request.Request(url, data=xml.encode("utf-8"),
                                 headers={"Content-Type": "text/xml; charset=utf-8"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    for enc in ("utf-8-sig", "utf-16"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def _clean(text: str) -> str:
    # Tally emits control-character references (e.g. &#4;) that break XML parsers
    text = re.sub(r"&#(\d+);", lambda m: "" if int(m.group(1)) < 32 and m.group(1) not in ("9", "10", "13") else m.group(0), text)
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)


def parse_xml(text: str) -> ET.Element:
    return ET.fromstring(_clean(text))


def collection(coll_type: str, fetch: list[str], company: str = "", from_date: str = "", to_date: str = "",
               name: str = "TDColl") -> list[ET.Element]:
    sv = "<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>"
    if company:
        sv += f"<SVCURRENTCOMPANY>{esc(company)}</SVCURRENTCOMPANY>"
    if from_date:
        sv += f"<SVFROMDATE>{to_tally_date(from_date)}</SVFROMDATE>"
    if to_date:
        sv += f"<SVTODATE>{to_tally_date(to_date)}</SVTODATE>"
    xml = (f"<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE>"
           f"<ID>{name}</ID></HEADER><BODY><DESC><STATICVARIABLES>{sv}</STATICVARIABLES><TDL><TDLMESSAGE>"
           f"<COLLECTION NAME=\"{name}\" ISMODIFY=\"No\"><TYPE>{coll_type}</TYPE><FETCH>{','.join(fetch)}</FETCH>"
           f"</COLLECTION></TDLMESSAGE></TDL></DESC></BODY></ENVELOPE>")
    root = parse_xml(tally_post(xml))
    tag = coll_type.upper().rstrip("S") if coll_type.lower() == "bills" else coll_type.upper()
    return list(root.iter(tag)) or list(root.iter("BILL"))


def txt(el: ET.Element, tag: str) -> str:
    v = el.findtext(tag)
    if v is None:
        v = el.get(tag) or ""
    return v.strip()


def amt(s: str) -> float:
    try:
        return round(float(re.sub(r"[^\d.\-]", "", s or "0") or 0), 2)
    except ValueError:
        return 0.0


def to_tally_date(d: str) -> str:
    d = str(d).strip()
    if re.fullmatch(r"\d{8}", d):
        return d
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", d)
    if m:
        return f"{m[1]}{int(m[2]):02d}{int(m[3]):02d}"
    m = re.fullmatch(r"(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})", d)
    if m:
        return f"{m[3]}{int(m[2]):02d}{int(m[1]):02d}"
    raise ValueError(f"Bad date '{d}' — use YYYY-MM-DD")


def iso_from_tally(d: str) -> str:
    return f"{d[:4]}-{d[4:6]}-{d[6:8]}" if re.fullmatch(r"\d{8}", d or "") else d


def drcr(closing: float) -> str:
    # Tally exports debit balances as negative numbers
    return "Dr" if closing < 0 else ("Cr" if closing > 0 else "Nil")


# ----------------------------------------------------------------------------- Read helpers
def get_companies() -> list[dict]:
    rows = collection("Company", ["Name", "StartingFrom", "BooksFrom"], name="TDCompanies")
    return [{"name": c.get("NAME") or txt(c, "NAME"), "books_from": iso_from_tally(txt(c, "BOOKSFROM"))} for c in rows]


def get_ledgers(company: str = "") -> list[dict]:
    rows = collection("Ledger", ["Name", "Parent", "ClosingBalance"], company=company, name="TDLedgers")
    out = []
    for l in rows:
        cb = amt(txt(l, "CLOSINGBALANCE"))
        out.append({"name": l.get("NAME") or txt(l, "NAME"), "group": txt(l, "PARENT"),
                    "closing": abs(cb), "dr_cr": drcr(cb)})
    return out


def gstin_valid(g: str) -> bool:
    g = (g or "").strip().upper()
    if not re.fullmatch(r"[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]", g):
        return False
    cs = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    total, factor = 0, 2
    for ch in reversed(g[:-1]):
        a = factor * cs.index(ch)
        factor = 1 if factor == 2 else 2
        total += a // 36 + a % 36
    return cs[(36 - total % 36) % 36] == g[-1]


# ----------------------------------------------------------------------------- Drafts (2-phase commit)
def _secret() -> bytes:
    if not SECRET_FILE.exists():
        SECRET_FILE.write_text(secrets.token_hex(32), encoding="utf-8")
        try:
            os.chmod(SECRET_FILE, 0o600)
        except OSError:
            pass
    return SECRET_FILE.read_text(encoding="utf-8").strip().encode()


def sign(draft_id: str) -> str:
    return hmac.new(_secret(), draft_id.encode(), hashlib.sha256).hexdigest()[:32]


def load_drafts() -> list[dict]:
    try:
        return json.loads(DRAFTS_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def save_drafts(drafts: list[dict]) -> None:
    tmp = DRAFTS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(drafts, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, DRAFTS_FILE)


def build_voucher_xml(vouchers: list[dict], draft_id: str) -> tuple[str, list[dict]]:
    blocks, ids = [], []
    for i, v in enumerate(vouchers):
        rid = f"TD-MCP-{draft_id}-{i}"
        ids.append({"remote_id": rid, "date": v["tdate"], "voucher_type": v["type"]})
        ents = "".join(
            f"<ALLLEDGERENTRIES.LIST><LEDGERNAME>{esc(e['ledger'])}</LEDGERNAME>"
            f"<ISDEEMEDPOSITIVE>{'Yes' if e['dr'] > 0 else 'No'}</ISDEEMEDPOSITIVE>"
            f"<AMOUNT>{(-e['dr'] if e['dr'] > 0 else e['cr']):.2f}</AMOUNT></ALLLEDGERENTRIES.LIST>"
            for e in v["entries"])
        num = f"<VOUCHERNUMBER>{esc(v['number'])}</VOUCHERNUMBER>" if v.get("number") else ""
        blocks.append(
            f'<TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER REMOTEID="{rid}" VCHTYPE="{esc(v["type"])}" ACTION="Create">'
            f"<DATE>{v['tdate']}</DATE><VOUCHERTYPENAME>{esc(v['type'])}</VOUCHERTYPENAME>{num}"
            f"<NARRATION>{esc(v.get('narration', ''))}</NARRATION>{ents}</VOUCHER></TALLYMESSAGE>")
    return envelope("\n".join(blocks)), ids


def envelope(body: str) -> str:
    return ("<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA>"
            "<REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME></REQUESTDESC><REQUESTDATA>\n"
            f"{body}\n</REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>")


def tally_result(text: str) -> dict:
    g = lambda t: int(m[1]) if (m := re.search(fr"<{t}>(\d+)</{t}>", text)) else 0
    return {"created": g("CREATED"), "altered": g("ALTERED"), "deleted": g("DELETED"), "errors": g("ERRORS"),
            "line_errors": re.findall(r"<LINEERROR>([^<]+)", text)[:10]}


def validate_vouchers(vouchers: list[dict], known: set[str] | None) -> tuple[list[dict], list[str], list[str]]:
    clean, errors, warnings = [], [], []
    for i, v in enumerate(vouchers, 1):
        vt = str(v.get("type", "")).strip().title().replace("Note", "Note")
        if vt not in VOUCHER_TYPES:
            errors.append(f"#{i}: voucher type '{v.get('type')}' not one of {sorted(VOUCHER_TYPES)}")
            continue
        try:
            tdate = to_tally_date(v.get("date", ""))
        except ValueError as e:
            errors.append(f"#{i}: {e}")
            continue
        ents = []
        for e in v.get("entries", []):
            led = str(e.get("ledger", "")).strip()
            dr, cr = round(float(e.get("dr") or 0), 2), round(float(e.get("cr") or 0), 2)
            if not led or (dr > 0) == (cr > 0) or dr < 0 or cr < 0:
                errors.append(f"#{i}: each entry needs a ledger and exactly one positive 'dr' or 'cr' ({e})")
                continue
            if known is not None and led.lower() not in known:
                warnings.append(f"#{i}: ledger '{led}' not found in Tally — create it before approving")
            ents.append({"ledger": led, "dr": dr, "cr": cr})
        sdr, scr = round(sum(x["dr"] for x in ents), 2), round(sum(x["cr"] for x in ents), 2)
        if len(ents) < 2 or sdr != scr:
            errors.append(f"#{i}: not balanced (Dr {sdr:.2f} vs Cr {scr:.2f}) or fewer than 2 entries")
            continue
        clean.append({"date": iso_from_tally(tdate), "tdate": tdate, "type": vt, "number": str(v.get("number", "")).strip(),
                      "narration": str(v.get("narration", "")).strip(), "entries": ents, "total": sdr})
    return clean, errors, warnings


def stage(title: str, vouchers: list[dict], action: str = "CREATE", xml: str | None = None,
          ids: list[dict] | None = None, parent: str = "") -> dict:
    draft_id = datetime.now().strftime("%y%m%d%H%M%S") + secrets.token_hex(2)
    if xml is None:
        xml, ids = build_voucher_xml(vouchers, draft_id)
    d = {"draft_id": draft_id, "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "title": title[:140],
         "action": action, "voucher_count": len(ids or []), "total_debit": round(sum(v.get("total", 0) for v in vouchers), 2),
         "status": "PENDING_APPROVAL", "sig": sign(draft_id), "vouchers": vouchers, "remote_ids": ids or [],
         "xml": xml, "parent": parent, "result": None}
    with _lock:
        drafts = load_drafts()
        drafts.insert(0, d)
        save_drafts(drafts[:300])
    log(f"STAGED {draft_id} {action} '{title}' ({d['voucher_count']} vouchers, ₹{d['total_debit']:.2f})")
    return d


def decide(draft_id: str, sig: str, approve: bool) -> dict:
    if not hmac.compare_digest(sign(draft_id), sig or ""):
        raise PermissionError("Bad signature")
    with _lock:
        drafts = load_drafts()
        d = next((x for x in drafts if x["draft_id"] == draft_id), None)
        if not d:
            raise KeyError("Draft not found")
        if d["status"] != "PENDING_APPROVAL":
            return d
        d["status"] = "APPROVING" if approve else "REJECTED"
        save_drafts(drafts)
    if not approve:
        log(f"REJECTED {draft_id}")
        return d
    try:
        res = tally_result(tally_post(d["xml"], timeout=180))
        status = "COMMITTED" if res["errors"] == 0 else ("PARTIAL" if res["created"] + res["altered"] + res["deleted"] else "FAILED")
    except Exception as e:  # network / Tally closed
        res, status = {"error": str(e)}, "PENDING_APPROVAL"
    with _lock:
        drafts = load_drafts()
        d = next(x for x in drafts if x["draft_id"] == draft_id)
        d["status"], d["result"], d["decided_at"] = status, res, datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_drafts(drafts)
    log(f"APPROVED {draft_id} -> {status} {res}")
    return d


# ----------------------------------------------------------------------------- HTTP bridge
ALLOWED_ORIGIN = re.compile(r"^(null|https?://(localhost|127\.0\.0\.1)(:\d+)?|https://g-avinash21\.github\.io)$")
PAGE_CSS = ("body{font:14px system-ui,Segoe UI,sans-serif;max-width:980px;margin:32px auto;padding:0 16px;color:#1d2333}"
            "table{border-collapse:collapse;width:100%;margin:14px 0}td,th{border:1px solid #e4e8f0;padding:7px 9px;text-align:left}"
            "th{background:#f4f6fb}.n{text-align:right;font-family:ui-monospace,monospace}button{font:600 14px system-ui;padding:10px 18px;"
            "border-radius:10px;border:0;cursor:pointer;margin-right:8px}.ok{background:#0f9f7f;color:#fff}.no{background:#eee}"
            ".tag{display:inline-block;padding:2px 10px;border-radius:99px;background:#eef1f7;font-size:12px;font-weight:700}")


class Bridge(BaseHTTPRequestHandler):
    server_version = "TallyDeskBridge/2026.11"

    def log_message(self, fmt, *args):  # keep stdout clean
        print("[bridge] " + fmt % args, file=sys.stderr)

    def _origin_ok(self) -> bool:
        o = self.headers.get("Origin")
        return o is None or bool(ALLOWED_ORIGIN.match(o))

    def _send(self, code: int, body: str, ctype: str = "application/json") -> None:
        b = body.encode("utf-8")
        self.send_response(code)
        o = self.headers.get("Origin")
        if o and ALLOWED_ORIGIN.match(o):
            self.send_header("Access-Control-Allow-Origin", o)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Tally-Port")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if "charset" not in ctype else ""))
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_OPTIONS(self):
        self._send(204 if self._origin_ok() else 403, "")

    def do_GET(self):
        if not self._origin_ok():
            return self._send(403, '{"error":"origin not allowed"}')
        u = urlparse(self.path)
        if u.path == "/api/ping":
            try:
                tally_post("<ENVELOPE><HEADER><TALLYREQUEST>Export</TALLYREQUEST></HEADER></ENVELOPE>", timeout=4)
                up = True
            except Exception:
                up = False
            return self._send(200, json.dumps({"ok": True, "tally": up, "tally_url": TALLY_URL}))
        if u.path == "/api/drafts":
            ds = [{k: v for k, v in d.items() if k not in ("xml", "vouchers")} for d in load_drafts()]
            return self._send(200, json.dumps({"drafts": ds}))
        if u.path == "/approve":
            q = parse_qs(u.query)
            return self._approve_page(q.get("draft_id", [""])[0], q.get("sig", [""])[0])
        if u.path == "/":
            return self._send(200, f"<style>{PAGE_CSS}</style><h2>Tally Desk bridge is running</h2><p>Tally: {esc(TALLY_URL)}</p>"
                                   "<p><a href='/drafts'>Pending AI drafts</a></p>", "text/html")
        if u.path == "/drafts":
            rows = "".join(f"<tr><td>{esc(d['created_at'])}</td><td>{esc(d['title'])}</td><td>{d['voucher_count']}</td>"
                           f"<td class=n>{d['total_debit']:,.2f}</td><td><span class=tag>{d['status']}</span></td>"
                           f"<td><a href='/approve?draft_id={d['draft_id']}&sig={d['sig']}'>Open</a></td></tr>" for d in load_drafts()[:100])
            return self._send(200, f"<style>{PAGE_CSS}</style><h2>AI drafts</h2><table><tr><th>Created</th><th>Title</th><th>Vouchers</th>"
                                   f"<th>₹ Debit</th><th>Status</th><th></th></tr>{rows}</table>", "text/html")
        self._send(404, '{"error":"not found"}')

    def do_POST(self):
        if not self._origin_ok():
            return self._send(403, '{"error":"origin not allowed"}')
        u = urlparse(self.path)
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n).decode("utf-8", "replace") if n else ""
        if u.path == "/api/tally":
            try:
                hp = self.headers.get("X-Tally-Port") or ""
                out = tally_post(body, timeout=180, port=int(hp) if re.fullmatch(r"90\d\d", hp) else None)
                log(f"BRIDGE forwarded {len(body)} bytes -> {tally_result(out)}")
                return self._send(200, out, "text/xml")
            except Exception as e:
                return self._send(502, json.dumps({"error": str(e)}))
        if u.path == "/approve":
            f = parse_qs(body)
            did, sig, dec = f.get("draft_id", [""])[0], f.get("sig", [""])[0], f.get("decision", [""])[0]
            try:
                d = decide(did, sig, dec == "approve")
            except (PermissionError, KeyError) as e:
                return self._send(403, f"<p>{esc(e)}</p>", "text/html")
            return self._approve_page(did, sig, done=d)
        self._send(404, '{"error":"not found"}')

    def _approve_page(self, did: str, sig: str, done: dict | None = None):
        if not hmac.compare_digest(sign(did), sig or ""):
            return self._send(403, "<p>Invalid or expired approval link.</p>", "text/html")
        d = done or next((x for x in load_drafts() if x["draft_id"] == did), None)
        if not d:
            return self._send(404, "<p>Draft not found.</p>", "text/html")
        rows = ""
        for v in d["vouchers"]:
            for j, e in enumerate(v.get("entries", [])):
                head = (f"<td rowspan={len(v['entries'])}>{esc(v['date'])}</td><td rowspan={len(v['entries'])}>{esc(v['type'])} "
                        f"{esc(v.get('number', ''))}<br><small>{esc(v.get('narration', ''))}</small></td>") if j == 0 else ""
                rows += (f"<tr>{head}<td>{esc(e['ledger'])}</td><td class=n>{e['dr']:,.2f}</td><td class=n>{e['cr']:,.2f}</td></tr>")
        if not rows:  # rollback drafts
            rows = "".join(f"<tr><td colspan=5>DELETE {esc(r['voucher_type'])} {esc(r['remote_id'])} dated {esc(r['date'])}</td></tr>"
                           for r in d.get("remote_ids", []))
        res = f"<p><b>Result:</b> {esc(json.dumps(d.get('result')))}</p>" if d.get("result") else ""
        form = (f"<form method=post action='/approve'><input type=hidden name=draft_id value='{esc(did)}'>"
                f"<input type=hidden name=sig value='{esc(sig)}'><button class=ok name=decision value=approve>Approve &amp; post to Tally</button>"
                f"<button class=no name=decision value=reject>Reject</button></form>") if d["status"] == "PENDING_APPROVAL" else ""
        html_ = (f"<style>{PAGE_CSS}</style><h2>{esc(d['title'])}</h2><p><span class=tag>{d['status']}</span> · {d['action']} · "
                 f"{d['voucher_count']} voucher(s) · ₹{d['total_debit']:,.2f} · staged {esc(d['created_at'])} · Tally {esc(TALLY_URL)}</p>"
                 f"<table><tr><th>Date</th><th>Voucher</th><th>Ledger</th><th class=n>Dr</th><th class=n>Cr</th></tr>{rows}</table>{res}{form}"
                 "<p><small>Take a Tally backup before approving large batches. Every voucher carries a REMOTEID so it can be rolled back.</small></p>")
        self._send(200, html_, "text/html")


APPROVE_PORT = BRIDGE_PORT


def start_bridge(block: bool) -> ThreadingHTTPServer | None:
    """Port 9190 is normally taken by "Tally Desk Auto.bat" — then the approval page (and a spare bridge) run on 9191."""
    global APPROVE_PORT
    srv = None
    for port in (BRIDGE_PORT, BRIDGE_PORT + 1):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), Bridge)
            APPROVE_PORT = port
            break
        except OSError:
            log(f"Port {port} busy (Tally Desk Auto is running there) — trying the next one")
    if srv is None:
        return None
    log(f"Bridge + approval page on http://127.0.0.1:{APPROVE_PORT} -> Tally {TALLY_URL}")
    if block:
        srv.serve_forever()
    else:
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv




# ----------------------------------------------------------------------------- Same-name suspense engine
# Mirrors Tally Desk: payer fingerprints learned from cleared receipts (remitter A/c, UPI ID, IFSC branch,
# cheque-book series per bank, payer text share) + open-bill subset sums incl. previous-FY bills.
BANKCODES = {"SIB", "HDF", "HDFC", "IDB", "IDBI", "YES", "KVB", "AXI", "AXIS", "UTI", "FED", "FDRL", "BOI", "BKID", "ICI", "ICIC", "SBI", "SBIN",
             "CNR", "CNRB", "CAN", "UBI", "UBIN", "KAR", "KARB", "KKB", "KKBK", "IOB", "IOBA", "BOB", "BARB", "PNB", "PUNB", "CBI", "CBIN",
             "IDF", "IDFB", "RBL", "RATN", "CSB", "CSBK", "TMB", "TMBL", "CIUB", "DCB", "BDBL", "INDB", "IND", "IDIB", "UCB", "UCBA", "MAH", "MAHB"}
AGGREGATOR = re.compile(r"PHONEPE|PAYTM|RAZORPAY|CASHFREE|BHARATPE|PINE ?LABS|BILLDESK|CCAVENUE|PAYU|GOOGLE ?PAY|AMAZON ?PAY|MSWIPE|EZETAP|PAYMENT AGGREGATOR")


def parse_narr(narr: str) -> dict:
    s = re.sub(r"\s+", " ", str(narr or "").upper()).strip()
    o = {"mode": (re.match(r"^(CLG|NEFT|RTGS|IMPS|UPI|MMT|INF|INFT|TRF|CHQ|CASH|NACH|ACH|MOB|IB|BRN)", s) or [""])[0],
         "payer": "", "chq": "", "bank": "", "ifsc": "", "acct": "", "vpa": "", "aggregator": ""}
    m = re.search(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", s); o["ifsc"] = m[0] if m else ""
    m = re.search(r"[A-Za-z0-9._-]{3,}@[A-Za-z]{2,}", str(narr or "")); o["vpa"] = m[0].lower() if m else ""
    accts = [x for x in re.findall(r"\b\d{9,18}\b", s) if not x.startswith("20") and len(x) != 16]
    o["acct"] = accts[-1] if accts else ""
    m = AGGREGATOR.search(s)
    if m:
        o["aggregator"] = m[0]
    elif s.startswith("CLG"):
        p = s.split("/")
        o["payer"] = (p[1] if len(p) > 1 else "").strip()
        o["chq"] = p[2] if len(p) > 2 and re.fullmatch(r"\d{5,7}", p[2]) else ""
        o["bank"] = (p[3] if len(p) > 3 else "").strip()[:4]
    else:
        segs = [x.strip() for x in re.split(r"[/|]+|-+", s) if x.strip()]
        words = [x for x in segs if re.search(r"[A-Z]{3,}", x) and not re.fullmatch(r"NEFT|RTGS|IMPS|UPI|CLG|INF|INFT|MMT|P2A|P2M|TRF|TPFT|MOB|CR|DR", x)
                 and not re.fullmatch(r"[A-Z]{4}0[A-Z0-9]{6}", x) and not re.search(r"\d{6,}", x.replace(" ", "")) and not re.search(r"BANK$|BANK LTD|^STATE BANK", x)]
        o["payer"] = re.sub(r"\s+", " ", re.sub(r"[^A-Z0-9 &.]", " ", max(words, key=lambda w: len(re.sub(r"[^A-Z ]", "", w)), default=""))).strip()
    if not o["bank"] and o["ifsc"]:
        o["bank"] = o["ifsc"][:4]
    o["payer_key"] = re.sub(r"[^A-Z0-9]", "", re.sub(r"\b(M/S|MS|PVT|LTD|LIMITED|LLP|PRIVATE|THE|AND|&)\b", " ", o["payer"]))
    return o


def _vouchers_with_entries(from_date: str, to_date: str, company: str = "") -> list[dict]:
    rows = collection("Voucher", ["Date", "VoucherNumber", "VoucherTypeName", "Narration", "RemoteID", "AllLedgerEntries.LedgerName", "AllLedgerEntries.Amount"],
                      company=company, from_date=from_date, to_date=to_date, name="TDVchEnt")
    out = []
    for v in rows:
        ents = [{"ledger": txt(e, "LEDGERNAME"), "amount": amt(txt(e, "AMOUNT"))} for e in v.iter("ALLLEDGERENTRIES.LIST")]
        out.append({"date": iso_from_tally(txt(v, "DATE")), "type": txt(v, "VOUCHERTYPENAME"), "number": txt(v, "VOUCHERNUMBER"),
                    "narration": txt(v, "NARRATION"), "remote_id": v.get("REMOTEID", ""), "entries": ents})
    return out


def fp_path(company: str) -> Path:
    return HOME / f"payer_fp_{re.sub(r'[^A-Za-z0-9]+', '_', company or 'default')[:60]}.json"


def learn_fingerprints(years: int = 2, group: str = "Sundry Debtors", suspense: str = "Suspense", company: str = "") -> dict:
    groups = {l["name"]: l["group"].lower() for l in get_ledgers(company)}
    bankish = lambda n: bool(re.search(r"bank|cash|od", groups.get(n, ""))) or "bank" in n.lower()
    today = date.today(); start = today.replace(year=today.year - max(1, min(5, years)))
    fp: dict[str, dict] = {}
    n = 0
    for v in _vouchers_with_entries(start.isoformat(), today.isoformat(), company):
        bank = [e for e in v["entries"] if e["amount"] < 0 and bankish(e["ledger"])]
        deb = [e for e in v["entries"] if e["amount"] > 0 and not bankish(e["ledger"]) and e["ledger"].lower() != suspense.lower()
               and (group.lower().replace("sundry ", "") in groups.get(e["ledger"], "debtor") or groups.get(e["ledger"]) == group.lower())]
        if not (bank and len(deb) == 1 and v["narration"]):
            continue
        p, L = parse_narr(v["narration"]), fp.setdefault(deb[0]["ledger"], {"acct": {}, "vpa": {}, "ifsc": {}, "chq": [], "payer": {}, "n": 0})
        L["n"] += 1; n += 1
        for k in ("acct", "vpa", "ifsc"):
            if p[k]:
                L[k][p[k]] = L[k].get(p[k], 0) + 1
        if p["chq"] and p["bank"]:
            L["chq"] = (L["chq"] + [[p["bank"], int(p["chq"])]])[-80:]
        if p["payer_key"]:
            L["payer"][p["payer_key"]] = L["payer"].get(p["payer_key"], 0) + 1
    data = {"learned_at": datetime.now().isoformat(timespec="seconds"), "receipts": n, "ledgers": fp, "keywords": load_fp(company).get("keywords", {})}
    fp_path(company).write_text(json.dumps(data))
    return data


def load_fp(company: str = "") -> dict:
    try:
        return json.loads(fp_path(company).read_text())
    except Exception:
        return {"ledgers": {}, "keywords": {}}


def subset_sum(bills: list[dict], target: float, max_k: int = 5, tol: float = 5.0) -> list[dict] | None:
    c = sorted([b for b in bills if b["pending"] > 0.01], key=lambda b: -b["pending"])[:24]
    for b in c:
        if abs(b["pending"] - target) <= tol:
            return [b]
    best, nodes = None, 0
    def dfs(i, chosen, s):
        nonlocal best, nodes
        nodes += 1
        if best or nodes > 20000:
            return
        if len(chosen) >= 2 and abs(s - target) <= tol:
            best = list(chosen); return
        if len(chosen) >= max_k or i >= len(c) or s > target + tol:
            return
        chosen.append(c[i]); dfs(i + 1, chosen, s + c[i]["pending"]); chosen.pop(); dfs(i + 1, chosen, s)
    dfs(0, [], 0.0)
    return best


def score_candidates(entry: dict, fp: dict, pool: list[str], bills: dict[str, list[dict]], fy_start: str) -> list[dict]:
    p, nu = parse_narr(entry["narration"]), entry["narration"].upper()
    if p["aggregator"]:
        return [{"ledger": f"{p['aggregator']} settlement", "confidence": 60, "reasons": [f"{p['aggregator']} payout — settle against UPI/card sales, not a debtor"], "bills": []}]
    led_fp, out = fp.get("ledgers", {}), []
    norm = lambda x: re.sub(r"[^A-Z0-9]", "", re.sub(r"\(.*?\)|\b[A-Z]?\d+[A-Z0-9]*\b", "", x.upper()))
    for led in pool:
        sc, why, L = 0, [], led_fp.get(led)
        for k, l in fp.get("keywords", {}).items():
            if l == led and k.upper() in nu:
                sc += 55; why.append(f"keyword '{k}'"); break
        if L:
            if p["acct"] and p["acct"] in L["acct"]:
                sc += 75; why.append(f"same remitter account …{p['acct'][-4:]} ({L['acct'][p['acct']]}x)")
            elif p["vpa"] and p["vpa"] in L["vpa"]:
                sc += 75; why.append(f"same UPI ID {p['vpa']}")
            elif p["ifsc"] and p["ifsc"] in L["ifsc"]:
                sc += 25; why.append(f"same paying branch {p['ifsc']}")
            if p["chq"] and p["bank"]:
                near = [c for b, c in L["chq"] if b == p["bank"] and abs(c - int(p["chq"])) <= 300]
                if near:
                    sc += 70; why.append(f"cheque {p['chq']} in the same {p['bank']} cheque book as {len(near)} earlier payment(s)")
            if p["payer_key"] and L["payer"].get(p["payer_key"]):
                tot = sum(x["payer"].get(p["payer_key"], 0) for x in led_fp.values()); share = L["payer"][p["payer_key"]] / tot
                if share >= 0.6:
                    sc += round(25 * share); why.append(f"payer text used for this ledger {L['payer'][p['payer_key']]} of {tot} times")
        name_hit = bool(p["payer_key"]) and (norm(led) in p["payer_key"] or p["payer_key"] in norm(led))
        if not name_hit and sc < 20:
            continue
        if name_hit:
            sc += 15; why.append("name matches")
        elig = [b for b in bills.get(led, []) if not b["date"] or b["date"] <= entry["date"] or b["date"] < fy_start]
        combo = subset_sum(elig, entry["amount"]) if elig else None
        if combo:
            prev = sum(1 for b in combo if b["date"] and b["date"] < fy_start)
            sc += 40 if len(combo) == 1 else 36
            why.append(f"{len(combo)} open bill(s) add up exactly" + (f" ({prev} from previous FY)" if prev else ""))
        out.append({"ledger": led, "confidence": max(1, min(99, sc)), "reasons": why, "bills": [{"bill": b["bill"], "date": b["date"], "amount": b["pending"]} for b in (combo or [])]})
    exact = [c for c in out if c["bills"]]
    if len(exact) == 1:
        exact[0]["confidence"] = min(99, exact[0]["confidence"] + 15); exact[0]["reasons"].append("only look-alike with an exact bill match")
    out.sort(key=lambda c: -c["confidence"])
    return out[:5]


# ----------------------------------------------------------------------------- MCP tools
def build_mcp():
    try:
        from mcp.server.mcpserver import MCPServer as Server  # mcp >= 2
    except ImportError:
        from mcp.server.fastmcp import FastMCP as Server  # mcp 1.x

    m = Server("tally-desk", instructions=(
        "Tools for the user's TallyPrime books on this computer. Reading is free. Writing is two-phase: "
        "stage_vouchers only creates a draft; the human must open the approval link and click Approve. "
        "Never claim an entry is posted until draft_status shows COMMITTED. Amounts are INR. "
        "Use dr/cr per entry; every voucher must balance."))

    @m.tool()
    def tally_status() -> dict:
        """Check whether TallyPrime is reachable and list the companies that are open."""
        try:
            return {"reachable": True, "tally_url": TALLY_URL, "companies": get_companies()}
        except Exception as e:
            return {"reachable": False, "tally_url": TALLY_URL, "error": str(e),
                    "fix": "Open TallyPrime with a company loaded; F1 > Settings > Connectivity > TallyPrime acts as Both/Server, port 9000."}

    @m.tool()
    def list_ledgers(search: str = "", group: str = "", min_balance: float = 0, limit: int = 200, company: str = "") -> dict:
        """List ledgers with group and closing balance (Dr/Cr). Filter by name text, group (e.g. 'Sundry Debtors') and minimum balance."""
        rows = [l for l in get_ledgers(company)
                if (not search or search.lower() in l["name"].lower())
                and (not group or group.lower() in l["group"].lower()) and l["closing"] >= min_balance]
        rows.sort(key=lambda r: -r["closing"])
        return {"count": len(rows), "ledgers": rows[:max(1, min(limit, 2000))]}

    @m.tool()
    def outstanding_bills(kind: str = "receivable", min_amount: float = 0, older_than_days: int = 0,
                          party: str = "", company: str = "") -> dict:
        """Bill-wise outstanding. kind='receivable' (Dr balances) or 'payable' (Cr). Ageing from bill date as of today."""
        bills = collection("Bills", ["Name", "Parent", "ClosingBalance", "BillDate"], company=company, name="TDBills")
        today, out = date.today(), []
        for b in bills:
            cb = amt(txt(b, "CLOSINGBALANCE"))
            if (kind == "receivable" and cb >= 0) or (kind == "payable" and cb <= 0):
                continue
            bd = iso_from_tally(txt(b, "BILLDATE"))
            try:
                age = (today - date.fromisoformat(bd)).days
            except ValueError:
                age = None
            p = txt(b, "PARENT")
            if abs(cb) < min_amount or (older_than_days and (age is None or age < older_than_days)) or (party and party.lower() not in p.lower()):
                continue
            out.append({"party": p, "bill": b.get("NAME") or txt(b, "NAME"), "bill_date": bd, "age_days": age, "pending": abs(cb)})
        out.sort(key=lambda r: -(r["age_days"] or 0))
        by_party: dict[str, float] = {}
        for r in out:
            by_party[r["party"]] = round(by_party.get(r["party"], 0) + r["pending"], 2)
        return {"bills": out[:1000], "total": round(sum(r["pending"] for r in out), 2),
                "by_party": dict(sorted(by_party.items(), key=lambda kv: -kv[1]))}

    @m.tool()
    def vouchers(from_date: str, to_date: str, voucher_type: str = "", party: str = "", text: str = "",
                 limit: int = 500, company: str = "") -> dict:
        """Day Book between two dates (YYYY-MM-DD). Optional filters: voucher type, party ledger text, narration text."""
        rows = collection("Voucher", ["Date", "VoucherNumber", "VoucherTypeName", "PartyLedgerName", "Amount", "Narration", "RemoteID"],
                          company=company, from_date=from_date, to_date=to_date, name="TDDayBook")
        out = []
        for v in rows:
            r = {"date": iso_from_tally(txt(v, "DATE")), "type": txt(v, "VOUCHERTYPENAME"), "number": txt(v, "VOUCHERNUMBER"),
                 "party": txt(v, "PARTYLEDGERNAME"), "amount": abs(amt(txt(v, "AMOUNT"))), "narration": txt(v, "NARRATION"),
                 "remote_id": v.get("REMOTEID", "")}
            if voucher_type and voucher_type.lower() != r["type"].lower():
                continue
            if party and party.lower() not in r["party"].lower():
                continue
            if text and text.lower() not in (r["narration"] + r["number"]).lower():
                continue
            out.append(r)
        return {"count": len(out), "total": round(sum(r["amount"] for r in out), 2), "vouchers": out[:max(1, min(limit, 5000))]}

    @m.tool()
    def tally_report(report: str = "Trial Balance", from_date: str = "", to_date: str = "", company: str = "", max_chars: int = 60000) -> str:
        """Export a built-in TallyPrime report as XML text, e.g. 'Trial Balance', 'Balance Sheet', 'Profit and Loss', 'Day Book', 'Ledger Outstandings'."""
        sv = "<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>"
        if company:
            sv += f"<SVCURRENTCOMPANY>{esc(company)}</SVCURRENTCOMPANY>"
        if from_date:
            sv += f"<SVFROMDATE>{to_tally_date(from_date)}</SVFROMDATE>"
        if to_date:
            sv += f"<SVTODATE>{to_tally_date(to_date)}</SVTODATE>"
        xml = (f"<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Data</TYPE><ID>{esc(report)}</ID>"
               f"</HEADER><BODY><DESC><STATICVARIABLES>{sv}</STATICVARIABLES></DESC></BODY></ENVELOPE>")
        return _clean(tally_post(xml))[:max_chars]

    @m.tool()
    def suspense_entries(from_date: str, to_date: str, suspense_ledger: str = "Suspense", company: str = "") -> dict:
        """Receipts sitting in the Suspense ledger (credited to Suspense, bank debited), with the narration parsed into
        payer name, cheque no., bank code, IFSC, remitter account and UPI ID."""
        out = []
        for v in _vouchers_with_entries(from_date, to_date, company):
            se = [e for e in v["entries"] if e["ledger"].lower() == suspense_ledger.lower() and e["amount"] > 0]
            if not se:
                continue
            bank = next((e["ledger"] for e in v["entries"] if e["amount"] < 0), "")
            out.append({**{k: v[k] for k in ("date", "type", "number", "narration", "remote_id")}, "amount": se[0]["amount"], "bank_ledger": bank,
                        "lines": len(v["entries"]), "parsed": parse_narr(v["narration"])})
        return {"count": len(out), "total": round(sum(r["amount"] for r in out), 2), "entries": out}

    @m.tool()
    def learn_payer_fingerprints(years: int = 2, debtor_group: str = "Sundry Debtors", suspense_ledger: str = "Suspense", company: str = "") -> dict:
        """Read years of cleared receipts and learn, per debtor ledger, which remitter accounts, UPI IDs, IFSC branches,
        cheque-book series and payer texts belong to it. Saved locally; used by suggest_suspense_ledgers."""
        d = learn_fingerprints(years, debtor_group, suspense_ledger, company)
        top = sorted(d["ledgers"].items(), key=lambda kv: -kv[1]["n"])[:25]
        return {"receipts_learned": d["receipts"], "debtors": len(d["ledgers"]),
                "sample": [{"ledger": k, "receipts": v["n"], "accounts": len(v["acct"]), "upi_ids": len(v["vpa"]), "cheque_books": len({b for b, _ in v["chq"]})} for k, v in top]}

    @m.tool()
    def set_payer_keyword(keyword: str, ledger: str, company: str = "") -> dict:
        """Teach a keyword (proprietor name, branch tag, GSTIN tail…) that always means this ledger — like the Bank Import TDL's 'Suggested Keyword'."""
        d = load_fp(company); d.setdefault("keywords", {})[keyword.strip().upper()] = ledger.strip(); fp_path(company).write_text(json.dumps(d))
        return {"ok": True, "keywords": len(d["keywords"])}

    @m.tool()
    def suggest_suspense_ledgers(from_date: str, to_date: str, suspense_ledger: str = "Suspense", debtor_group: str = "Sundry Debtors", company: str = "") -> dict:
        """For every Suspense receipt, rank the look-alike debtor ledgers (e.g. 'City Mart 1' vs 'City Mart - P1Z2') using learned payer
        fingerprints, keywords and open-bill subset sums (clubbed bills, short payments, March bills paid in April). Read-only."""
        fp = load_fp(company)
        groups = {l["name"]: l["group"].lower() for l in get_ledgers(company)}
        pool = [n for n, g in groups.items() if "debtor" in g or g == debtor_group.lower()]
        bills: dict[str, list[dict]] = {}
        for b in collection("Bills", ["Name", "Parent", "ClosingBalance", "BillDate"], company=company, name="TDBills"):
            cb = amt(txt(b, "CLOSINGBALANCE"))
            if cb < 0:  # receivable
                bills.setdefault(txt(b, "PARENT"), []).append({"bill": b.get("NAME") or txt(b, "NAME"), "date": iso_from_tally(txt(b, "BILLDATE")), "pending": abs(cb)})
        y = int(from_date[:4]); fy_start = f"{y if int(from_date[5:7]) >= 4 else y - 1}-04-01"
        ent = suspense_entries(from_date, to_date, suspense_ledger, company)["entries"]
        res = [{"entry": {k: e[k] for k in ("date", "number", "type", "amount", "narration", "remote_id", "bank_ledger")},
                "candidates": score_candidates(e, fp, pool, bills, fy_start)} for e in ent]
        clear = sum(1 for r in res if r["candidates"] and r["candidates"][0]["confidence"] >= 80 and (len(r["candidates"]) < 2 or r["candidates"][0]["confidence"] - r["candidates"][1]["confidence"] >= 15))
        return {"fingerprints_learned_at": fp.get("learned_at"), "entries": len(res), "clear_winners": clear, "results": res}

    @m.tool()
    def stage_suspense_clearing(items: list[dict], suspense_ledger: str = "Suspense") -> dict:
        """Stage alterations that move Suspense receipts to the chosen debtor, with optional bill allocations.
        items: [{remote_id, date, voucher_type, number, amount, bank_ledger, new_ledger, narration?, bills?:[{bill, amount}]}].
        Nothing reaches Tally until the person approves it on the approval page."""
        blocks, ids, vs = [], [], []
        for it in items:
            a = round(float(it["amount"]), 2); td = to_tally_date(it["date"])
            bl = "".join(f"<BILLALLOCATIONS.LIST><NAME>{esc(b['bill'])}</NAME><BILLTYPE>Agst Ref</BILLTYPE><AMOUNT>{float(b['amount']):.2f}</AMOUNT></BILLALLOCATIONS.LIST>" for b in it.get("bills", []))
            left = round(a - sum(float(b["amount"]) for b in it.get("bills", [])), 2)
            if left > 0.004:
                bl += f"<BILLALLOCATIONS.LIST><BILLTYPE>On Account</BILLTYPE><AMOUNT>{left:.2f}</AMOUNT></BILLALLOCATIONS.LIST>"
            head = f'<VOUCHER REMOTEID="{esc(it["remote_id"])}" VCHTYPE="{esc(it.get("voucher_type", "Receipt"))}" ACTION="Alter">' if it.get("remote_id") else \
                   f'<VOUCHER VCHTYPE="{esc(it.get("voucher_type", "Receipt"))}" ACTION="Create">'
            blocks.append(f'<TALLYMESSAGE xmlns:UDF="TallyUDF">{head}<DATE>{td}</DATE><VOUCHERTYPENAME>{esc(it.get("voucher_type", "Receipt"))}</VOUCHERTYPENAME>'
                          + (f"<VOUCHERNUMBER>{esc(it['number'])}</VOUCHERNUMBER>" if it.get("number") else "")
                          + f"<NARRATION>{esc(it.get('narration', ''))}</NARRATION>"
                          + f"<ALLLEDGERENTRIES.LIST><LEDGERNAME>{esc(it['bank_ledger'])}</LEDGERNAME><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><AMOUNT>-{a:.2f}</AMOUNT></ALLLEDGERENTRIES.LIST>"
                          + f"<ALLLEDGERENTRIES.LIST><LEDGERNAME>{esc(it['new_ledger'])}</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><AMOUNT>{a:.2f}</AMOUNT>{bl}</ALLLEDGERENTRIES.LIST></VOUCHER></TALLYMESSAGE>")
            ids.append({"remote_id": it.get("remote_id", ""), "date": td, "voucher_type": it.get("voucher_type", "Receipt")})
            vs.append({"date": it["date"], "type": it.get("voucher_type", "Receipt"), "narration": f"Suspense → {it['new_ledger']}", "total": a,
                       "entries": [{"ledger": it["bank_ledger"], "dr": a, "cr": 0}, {"ledger": it["new_ledger"], "dr": 0, "cr": a}]})
        d = stage(f"Clear {len(items)} suspense receipt(s)", vs, action="ALTER", xml=envelope("\n".join(blocks)), ids=ids)
        return {"draft_id": d["draft_id"], "status": d["status"], "approve_at": f"http://127.0.0.1:{APPROVE_PORT}/approve?draft_id={d['draft_id']}&sig={d['sig']}"}

    @m.tool()
    def validate_gstin(gstin: str) -> dict:
        """Offline GSTIN check: 15-char format, state code and Mod-36 check digit; also returns the embedded PAN."""
        g = gstin.strip().upper()
        return {"gstin": g, "valid": gstin_valid(g), "state_code": g[:2], "pan": g[2:12]}

    @m.tool()
    def stage_vouchers(title: str, vouchers: list[dict]) -> dict:
        """Stage vouchers for HUMAN approval (nothing is written to Tally yet).
        Each voucher: {"date":"YYYY-MM-DD","type":"Payment|Receipt|Journal|Contra|Sales|Purchase|Credit Note|Debit Note",
        "number":"optional","narration":"text","entries":[{"ledger":"HDFC Bank","cr":1000},{"ledger":"Rent","dr":1000}]}.
        Each voucher must balance (sum dr == sum cr). Returns an approval URL the user must open."""
        try:
            known = {l["name"].lower() for l in get_ledgers()}
        except Exception:
            known = None
        clean, errors, warnings = validate_vouchers(vouchers, known)
        if errors:
            return {"staged": False, "errors": errors, "warnings": warnings}
        d = stage(title, clean)
        return {"staged": True, "draft_id": d["draft_id"], "voucher_count": d["voucher_count"], "total": d["total_debit"],
                "warnings": warnings + ([] if known is not None else ["Tally not reachable: ledger names not verified"]),
                "approval_url": f"http://127.0.0.1:{APPROVE_PORT}/approve?draft_id={d['draft_id']}&sig={d['sig']}",
                "next": "Ask the user to open approval_url (or Tally Desk > AI / MCP Approval Gate) and click Approve."}

    @m.tool()
    def draft_status(draft_id: str = "") -> dict:
        """Status of one draft (or the latest 20): PENDING_APPROVAL, COMMITTED, PARTIAL, FAILED, REJECTED, with Tally's import result."""
        ds = load_drafts()
        if draft_id:
            ds = [d for d in ds if d["draft_id"] == draft_id]
        return {"drafts": [{k: d.get(k) for k in ("draft_id", "title", "action", "status", "voucher_count", "total_debit",
                                                     "created_at", "decided_at", "result")} for d in ds[:20]]}

    @m.tool()
    def stage_rollback(draft_id: str) -> dict:
        """Stage deletion of every voucher created by a COMMITTED/PARTIAL draft (by REMOTEID). Also needs human approval."""
        d = next((x for x in load_drafts() if x["draft_id"] == draft_id), None)
        if not d or d["status"] not in ("COMMITTED", "PARTIAL") or d["action"] != "CREATE":
            return {"staged": False, "error": "Only committed CREATE drafts can be rolled back."}
        body = "\n".join(f'<TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER REMOTEID="{esc(r["remote_id"])}" VCHTYPE="{esc(r["voucher_type"])}" '
                         f'ACTION="Delete"><DATE>{r["date"]}</DATE><VOUCHERTYPENAME>{esc(r["voucher_type"])}</VOUCHERTYPENAME></VOUCHER></TALLYMESSAGE>'
                         for r in d["remote_ids"])
        nd = stage(f"ROLLBACK of {draft_id}: {d['title']}", [], action="DELETE", xml=envelope(body), ids=d["remote_ids"], parent=draft_id)
        return {"staged": True, "draft_id": nd["draft_id"],
                "approval_url": f"http://127.0.0.1:{APPROVE_PORT}/approve?draft_id={nd['draft_id']}&sig={nd['sig']}"}

    return m


def selftest() -> int:
    print(f"Python {sys.version.split()[0]} · home {HOME} · Tally {TALLY_URL}")
    try:
        import mcp  # noqa: F401
        print("mcp package: OK")
    except ImportError:
        print("mcp package: MISSING  ->  pip install mcp")
    try:
        cos = get_companies()
        print(f"Tally: OK · companies: {', '.join(c['name'] for c in cos) or '(none open)'}")
        print(f"Ledgers: {len(get_ledgers())}")
    except Exception as e:
        print(f"Tally: NOT REACHABLE ({e}). Open TallyPrime; F1 > Settings > Connectivity > acts as Both, port 9000.")
        return 1
    assert gstin_valid("29AABCU9603R1ZJ") and not gstin_valid("29AABCU9603R1ZX")
    return 0


if __name__ == "__main__":
    mode = (sys.argv[1] if len(sys.argv) > 1 else "mcp").lower()
    if mode == "bridge":
        start_bridge(block=True)
    elif mode == "selftest":
        sys.exit(selftest())
    else:
        start_bridge(block=False)
        build_mcp().run()
